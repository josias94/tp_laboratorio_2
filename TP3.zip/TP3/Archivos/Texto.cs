﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        string ruta = AppDomain.CurrentDomain.BaseDirectory;

        public bool Guardar(string archivo, string datos)
        {
            StreamWriter escritor = new StreamWriter(ruta + archivo);
            escritor.WriteLine(datos);
            escritor.Close();
            return true;
        }

        public bool Leer(string archivo, out string datos)
        {
            StreamReader lector = new StreamReader(ruta + archivo);
            datos = lector.ReadToEnd();
            lector.Close();
            return true;
        }
    }
}
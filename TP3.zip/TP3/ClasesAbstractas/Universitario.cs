﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    //en el == nose que es eso del tipo
    public abstract class Universitario:Persona
    {
        #region Atributos
        protected int _legajo;
        #endregion

        #region Constructores
        public Universitario()
        {

        }

        public Universitario(int legajo,string nombre,string apellido,string dni,ENacionalidad nacionalidad)
            :base(nombre,apellido,dni,nacionalidad)
        {
            this._legajo = legajo;
        }
        #endregion

        #region Metodos
        protected abstract string ParticiparEnClase();

        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());            
            sb.AppendLine("LEGAJO NUMERO: " + this._legajo);
            return sb.ToString();
        }
        #endregion

        #region Sobrecarga de operadores
        public static bool operator==(Universitario pg1,Universitario pg2)
        {
            return pg1._legajo == pg2._legajo || pg1.DNI == pg2.DNI;
        }

        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }

        public override bool Equals(object obj)
        {
            bool retorno=false;

            if (obj is Universitario)
            {
                if(this == (Universitario)obj)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        #endregion
    }
}

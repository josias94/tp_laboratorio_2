﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class ArchivoLecturaException:Exception
    {
        public ArchivoLecturaException():base("No se puso leer el archivo")
        {

        }
    }
}

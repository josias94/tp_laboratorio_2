﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesInstanciables;
using ClasesAbstractas;
namespace ClasesInstanciables
{
    public sealed class Profesor:Universitario
    {            
        #region Atributos
        private Queue<Universidad.EClases> _clasesDelDia;
        private static Random _random;
        #endregion

        #region Constructores
        static Profesor()
        {
            Profesor._random = new Random();
        }

        public Profesor()
            :this(0, "","","1",ENacionalidad.Argentino)
        {
 
        }

        public Profesor(int id,string nombre,string apellido,string dni,Persona.ENacionalidad nacionalidad)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            this.RandomClases();
        }
        #endregion

        #region Metodos
        private void RandomClases()
        {
            for(int i=0;i<2;i++)
            {
                switch (Profesor._random.Next(1,5))
                {
                    case 1:
                        this._clasesDelDia.Enqueue(Universidad.EClases.Programacion);
                        break;
                    case 2:
                        this._clasesDelDia.Enqueue(Universidad.EClases.Laboratorio);
                        break;
                    case 3:
                        this._clasesDelDia.Enqueue(Universidad.EClases.Legislacion);
                        break;
                    case 4:
                        this._clasesDelDia.Enqueue(Universidad.EClases.SPD);
                        break;
                    default:  
                        break;
                }
            }
        }
        public override string ToString()
        {         
            return this.MostrarDatos();
        }

        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.MostrarDatos());         
            sb.Append(this.ParticiparEnClase());
            return sb.ToString(); 
        }

        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
       
            sb.AppendLine("CLASES DEL DIA: ");       
            
            foreach(Universidad.EClases clase in this._clasesDelDia)
            {
                sb.AppendLine(clase.ToString());
            }
                 
            return sb.ToString();
        }
        #endregion

        #region Sobrecarga operadores
        public static bool operator ==(Profesor p, Universidad.EClases clase)
        {
            bool retorno=false;

            foreach (Universidad.EClases c in p._clasesDelDia)
            {
                if (c == clase)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Profesor p, Universidad.EClases clase)
        {
            return !(p == clase);
        }
        #endregion
    }
}

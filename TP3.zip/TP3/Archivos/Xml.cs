﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        string ruta = AppDomain.CurrentDomain.BaseDirectory;
        public bool Guardar(string archivo, T datos)
        {
            TextWriter escritor = new StreamWriter(ruta + archivo);
            XmlSerializer serializador = new XmlSerializer(typeof(T));
            serializador.Serialize(escritor, datos);
            escritor.Close();
            return true;
        }

        public bool Leer(string archivo, out T datos)
        {
            TextReader lectura = new StreamReader(ruta + archivo);
            XmlSerializer deserializador = new XmlSerializer(typeof(T));
            datos = (T)deserializador.Deserialize(lectura);
            lectura.Close();
            return true;
        }
    }
}
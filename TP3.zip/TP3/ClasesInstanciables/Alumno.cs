﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;


namespace ClasesInstanciables
{
    //lo termine creo
    public sealed class Alumno : Universitario
    {

        #region Atributos
        Universidad.EClases _claseQueToma;
        EEstadoCuenta _estadoCuenta;
        #endregion

        #region Constructores
        public Alumno()
        {

        }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this._claseQueToma = claseQueToma;
        }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta)
            : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this._estadoCuenta = estadoCuenta;
        }
        #endregion

        #region Metodos
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("TOMA CLASES DE " + this._claseQueToma.ToString());
            return sb.ToString();
        }

        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.Append("ESTADO DE CUENTA: ");
            switch (this._estadoCuenta)
            {
                case EEstadoCuenta.AlDia:
                    sb.AppendLine("Cuota al dia");
                    break;
                case EEstadoCuenta.Deudor:
                    sb.AppendLine("Deudor");
                    break;
                case EEstadoCuenta.Becado:
                    sb.AppendLine("Becado");
                    break;
                default:
                    break;
            }
            sb.Append(this.ParticiparEnClase());
            return sb.ToString();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.MostrarDatos());
            return sb.ToString();
        }
        #endregion

        #region Sobrecarga operadores
        public static bool operator ==(Alumno a, Universidad.EClases clase)
        {
            return a._estadoCuenta != EEstadoCuenta.Deudor && a._claseQueToma == clase;
        }

        public static bool operator !=(Alumno a, Universidad.EClases clase)
        {
            return !(a == clase);
        }
        #endregion

        #region Enumerado
        public enum EEstadoCuenta
        {
            AlDia, Deudor, Becado
        }
        #endregion
    }
}

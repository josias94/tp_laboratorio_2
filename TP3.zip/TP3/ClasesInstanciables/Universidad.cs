﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    public class Universidad
    {
        //aca para crear una jornada en el constructor manda el 
        //intructor . dequeue de la clase que da... sino sale cualquier cosa
        // propiedad this[int i]-set-else nose si va o no
        #region Atributos
        private List<Alumno> _alumnos;
        private List<Jornada> _jornada;
        private List<Profesor> _profesores;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos { get { return this._alumnos; } set { this._alumnos = value; } }

        public List<Profesor> Profesores { get { return this._profesores; } set { this._profesores = value; } }

        public List<Jornada> Jornada { get { return this._jornada; } set { this._jornada = value; } }

        public Jornada this[int i]
        {
            get
            {
                if (i < this._jornada.Count && i >= 0)
                {
                    return this._jornada[i];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (i < this._jornada.Count && i > 0)
                {
                    this._jornada[i] = value;
                }
                //else -exception? o aviso?
            }
        }
        #endregion

        #region Constructores
        public Universidad()
        {
            this._alumnos = new List<Alumno>();
            this._jornada = new List<Jornada>();
            this._profesores = new List<Profesor>();
        }
        #endregion

        #region Metodos
        private static string MostrarDatos(Universidad g)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("JORNADA: ");                   
            foreach (Jornada j in g.Jornada)
            {
                sb.Append(j.ToString());
                sb.AppendLine("<------------------------------------------------>");
            }
            return sb.ToString();
        }

        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }

        public static bool Guardar(Universidad g)
        {
            Xml<Universidad> archivo = new Xml<Universidad>();          
            return archivo.Guardar("Universidad.xml", g);
        }

        public static Universidad Leer()
        {
            Universidad g = new Universidad();
            Xml<Universidad> archivo = new Xml<Universidad>();
            archivo.Leer("Universidad.xml", out g);
            return g;               
        }
        #endregion

        #region Sobrecarga de Operadores
        public static bool operator ==(Universidad g, Alumno a)
        {
            bool retorno = false;     
            foreach (Alumno aux in g.Alumnos)
            {
                if (a == aux)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        public static bool operator ==(Universidad g, Profesor i)
        {
            bool retorno = false;

            foreach (Profesor aux in g.Profesores)
            {
                if (i == aux)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor aux in g.Profesores)
            {
                if (aux == clase)
                {
                    return aux;
                }
            }
            throw new SinProfesorException();
        }

        public static Profesor operator !=(Universidad g, EClases clase)
        {
            foreach (Profesor aux in g.Profesores)
            {
                if (aux != clase)
                {
                    return aux;
                }
            }
            //si todos los profesores pueden dar la clase???
            return null;
        }


        public static Universidad operator +(Universidad g, Alumno a)
        {
            Universidad retorno = g;
            try
            {
                if (retorno != a)
                {
                    retorno.Alumnos.Add(a);
                }
                else
                {
                    throw new AlumnoRepetidoException();
                }
            }
            catch(AlumnoRepetidoException e)
            {
                Console.WriteLine(e.Message);
            }
            
            return retorno;
        }

        public static Universidad operator +(Universidad g, EClases clase)
        {
            Universidad retorno = g;
            
            Jornada jornada = new Jornada(clase, retorno == clase);
            foreach(Alumno a in retorno.Alumnos)
            {
                if(a==clase)
                {
                    jornada+=a;
                }
            }
            retorno.Jornada.Add(jornada);

            return retorno;
        }

        public static Universidad operator +(Universidad g, Profesor i)
        {
            Universidad retorno = g;
            if (retorno != i)
            {
                retorno.Profesores.Add(i);
            }
            return retorno;
        }
        #endregion

        #region Enumerado
        public enum EClases
        {
            Programacion = 1, Laboratorio, Legislacion, SPD
        }
        #endregion
    }
}

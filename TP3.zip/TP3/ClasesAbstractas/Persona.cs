﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    //propiedad
    //StringToDni esta mal me la re juego// listo
    //metodos
    //las validar las 3 excepciones
    //BORRAR EL DNI DE MOSTRARDATOS 
    public abstract class Persona
    {
        #region Atributos
        private string _nombre;
        private string _apellido;
        private int _dni;
        private ENacionalidad _nacionalidad;
        #endregion

        #region Propiedades
        public string Nombre 
        { 
            get 
            { 
                return this._nombre;
            }
            set
            {
                this._nombre = this.ValidarNombreApellido(value);
            }
        }

        public string Apellido
        {
            get
            {
                return this._apellido;
            }
            set
            {
                this._apellido = value;
            }
        }

        public int DNI
        {
            get
            {
                return this._dni;
            }
            set
            {
                this._dni = this.ValidarDni(this.Nacionalidad,value);
            }
        }

        public ENacionalidad Nacionalidad
        {
            get
            {
                return this._nacionalidad;
            }
            set
            {
                this._nacionalidad = value;
            }
        }

        public string StringToDNI
        {
            set
            {
                this._dni = this.ValidarDni(this.Nacionalidad, value);
            }
        }
        #endregion

        #region Constructores
        public Persona()
        {

        }

        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
            :this()
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._nacionalidad = nacionalidad;
        }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,dni.ToString(),nacionalidad)
        {

        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.StringToDNI = dni;
        }

        #endregion

        #region Metodos
        public int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            switch (nacionalidad)
            {
                case ENacionalidad.Argentino:
                    if(dato<1||dato>89999999)
                    {
                        //NacionalidadInvalidaException
                    }
                    break;
                case ENacionalidad.Extranjero:
                    if(dato<90000000)
                    {
                        //NacionalidadInvalidaException
                    }
                    break;
                default:
                    break;
            }
            return dato;
        }

        public int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            foreach (char l in dato)
            {
                if (!(char.IsDigit(l)))
                {
                    //DniInvalidoException
                }
            }
            return ValidarDni(nacionalidad, int.Parse(dato));   
        }

        private string ValidarNombreApellido(string dato)
        {
            foreach(char l in dato)
            {
                if(!char.IsLetter(l))
                {
                    //da la excepcion
                }
            }
            return dato;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("NOMBRE COMPLETO: "+this.Apellido +", "+ this.Nombre);    
            sb.AppendLine("NACIONALIDAD: " + this.Nacionalidad);
            sb.AppendLine("ACORDATE DE BORRAR Dni: " + this.DNI);//BORRAR
            return sb.ToString();
        }
        #endregion

        #region Enumerados

        public enum ENacionalidad
        {
            Argentino, Extranjero
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        string ruta = AppDomain.CurrentDomain.BaseDirectory;
        string _archivo;

        public Texto(string archivo)
        {
            this._archivo = archivo;
        }

        public bool guardar(string datos)
        {
            try
            {
               using (StreamWriter escritor = new StreamWriter(ruta+this._archivo,true))
               {
                   escritor.WriteLine(datos);
               }
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }


        public bool leer(out List<string> datos)
        {
            datos = new List<string>();
            try
            {
                using(StreamReader lector = new StreamReader(ruta + this._archivo))
                {
                    while (lector.EndOfStream == false)
                    {
                        datos.Add(lector.ReadLine());
                    }
                }          
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }

    }
}

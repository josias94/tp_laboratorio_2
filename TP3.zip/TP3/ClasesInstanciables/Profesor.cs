﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesInstanciables;
using ClasesAbstractas;
namespace ClasesInstanciables
{
    public sealed class Profesor:Universitario
    {
        //participarEnClase falta la cola
        //sobrecarga creo que esta borrando
        //constructor metodo ramdom
        #region Atributos
        private Queue<Universidad.EClases> _clasesDelDia;
        private static Random _random;
        #endregion

        #region Constructores
        static Profesor()
        {
            Profesor._random = new Random();
        }

        public Profesor()
        {
 
        }

        public Profesor(int id,string nombre,string apellido,string dni,Persona.ENacionalidad nacionalidad)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            //randomClases();
        }
        #endregion

        #region Metodos
        //private void RandomClases()
        //{
        //    Profesor._random.Next(4);
        //}
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.MostrarDatos());
            return sb.ToString();
        }

        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());         
            sb.AppendLine(this.ParticiparEnClase());
            return sb.ToString(); 
        }

        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CLASES DEL DIA: ");
            for (int i = 0; i < this._clasesDelDia.Count; i++)
            {
                sb.AppendLine(this._clasesDelDia.Dequeue().ToString());
            }
            return sb.ToString();
        }
        #endregion

        #region Sobrecarga operadores
        public static bool operator ==(Profesor p, Universidad.EClases clase)
        {
            bool retorno=false;
            for (int i = 0; i < p._clasesDelDia.Count;i++ )
            {
                if(clase==p._clasesDelDia.Dequeue())
                {
                    retorno=true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Profesor p, Universidad.EClases clase)
        {
            return !(p == clase);
        }
        #endregion
    }
}

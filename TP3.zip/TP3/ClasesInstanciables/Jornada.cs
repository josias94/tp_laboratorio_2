﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
   
    public class Jornada
    {
        #region Atributos
        private List<Alumno> _alumnos;
        private Universidad.EClases _clase;
        private Profesor _instrutor;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos { get { return this._alumnos; } set { this._alumnos = value; } }

        public Universidad.EClases Clases { get { return this._clase; } set { this._clase = value; } }

        public Profesor Instructor { get { return this._instrutor; } set { this._instrutor = value; } }
        #endregion

        #region Constructores
        private Jornada()
        {
            this._alumnos = new List<Alumno>();
        }

        public Jornada(Universidad.EClases clase, Profesor instructor)
            : this()
        {
            this._instrutor = instructor;
            this._clase = clase;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("CLASE DE " + this.Clases.ToString() + " ");
            sb.AppendLine(this.Instructor.ToString());
            sb.AppendLine("ALUMNOS: ");
            foreach (Alumno a in this.Alumnos)
            {
                sb.Append(a.ToString());
            }
            return sb.ToString();
        }

        public static bool Guardar(Jornada jornada)
        {
            Texto archivoTxt = new Texto();
            return archivoTxt.Guardar("Jornada.txt", jornada.ToString());
        }

        public static string Leer()
        {
            Texto archivoTxt = new Texto();
            string retorno;
            archivoTxt.Leer("Jornada.txt", out retorno);
            return retorno;
        }
        #endregion

        #region Sobrecarga operadores
        public static bool operator ==(Jornada j, Alumno a)
        {
            bool retorno = false;
            if (j._instrutor == a)
            {
                retorno = true;
            }
            foreach (Alumno aux in j.Alumnos)
            {
                if (((Universitario)a).Equals(aux))
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            Jornada retorno = j;

            try
            {
                if (retorno != a)
                {
                    retorno.Alumnos.Add(a);
                }
                else
                {
                    throw new AlumnoRepetidoException();
                }
            }
            catch(AlumnoRepetidoException e)
            {
                Console.WriteLine(e.Message);
            }
            return retorno;
        }
        #endregion

    }
}
